package com.example.indreshprakash.testing;


public interface OnButtonSwitchedListener {
    void onButtonSwitched(boolean isLogin);
}
