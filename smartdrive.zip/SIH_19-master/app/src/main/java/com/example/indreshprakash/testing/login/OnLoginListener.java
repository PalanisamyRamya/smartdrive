package com.example.indreshprakash.testing.login;

public interface OnLoginListener {
    void login();
}
