package com.example.indreshprakash.testing.login;

public interface OnSignUpListener {
    void signUp();
}
